
## Comando para correcta ejecución

1.  **Inciar el servicio de Inventario:**
    ```bash
    node server.js
    ```

2.  **Ejecutar en otra consola el autenticador de empleados:**
    ```bash
    node .\auth_administracion\emplserv.js
    ```
    


