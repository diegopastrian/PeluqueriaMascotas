 **comandos para testear servicio de autenticacino:**
 
acivar servicio desde directorio raiz
  ```bash
    node .\services\s2_gestion_clientes\server.js
  ```
 
desde directorio raiz realizar el test
   ```bash
    node .\clients\cliente_ping_test\test.js
   ```
