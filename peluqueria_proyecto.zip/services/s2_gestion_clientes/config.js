// s2_gestion_clientes/config.js

module.exports = {
    BUS_HOST: 'localhost',
    BUS_PORT: 5000,
    SERVICE_CODE: 'CLIEN',
    SERVICE_NAME_CODE: 'CLIEN', // Puedes mantener este nombre para los logs
    SECRET_KEY: 'tu_clave_secreta_muy_segura',
    HEALTH_PORT: 3001
};