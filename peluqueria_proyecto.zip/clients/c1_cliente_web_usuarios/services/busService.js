const net = require('net');
const EventEmitter = require('events');
const { buildTransaction, parseResponse } = require('../../../bus_service_helpers/transactionHelper');

const BUS_HOST = 'localhost';
const BUS_PORT = 5000;

class BusService extends EventEmitter {
    constructor() {
        super();
        this.clientSocket = new net.Socket();
        this.isConnected = false;
        this.buffer = ''; // <-- Buffer para acumular datos
    }

    connect() {
        if (this.isConnected) return;
        this.clientSocket.connect(BUS_PORT, BUS_HOST, () => {
            this.isConnected = true;
            console.log('[Bus] Conectado exitosamente.');
            this.emit('connect');
        });

        this.clientSocket.on('data', (data) => {
            // Acumular los datos recibidos en el buffer
            this.buffer += data.toString();
            this.processBuffer(); // Intentar procesar el buffer
        });

        this.clientSocket.on('close', () => {
            this.isConnected = false;
            console.log('[Bus] Conexion cerrada.');
            this.emit('close');
        });

        this.clientSocket.on('error', (err) => {
            console.error(`[Bus] Error de conexion: ${err.message}`);
            this.emit('error', err);
        });
    }

    processBuffer() {
        // Mientras haya al menos un mensaje completo en el buffer
        while (this.buffer.length > 5) {
            const lengthStr = this.buffer.substring(0, 5);
            // Comprobar si el prefijo de longitud es válido
            if (!/^\d{5}$/.test(lengthStr)) {
                // Si el buffer empieza con datos corruptos, lo limpiamos para evitar un bucle infinito
                console.error(`[Bus] Buffer corrupto, prefijo inválido: ${lengthStr}. Limpiando buffer.`);
                this.buffer = '';
                return;
            }

            const messageLength = parseInt(lengthStr, 10);
            const totalLength = 5 + messageLength;

            // Si no hemos recibido el mensaje completo, esperamos más datos
            if (this.buffer.length < totalLength) {
                return; // Salir y esperar el siguiente chunk de datos
            }

            // Si tenemos un mensaje completo, lo extraemos
            const message = this.buffer.substring(0, totalLength);
            // Y lo quitamos del buffer
            this.buffer = this.buffer.substring(totalLength);

            // Ahora procesamos el mensaje completo
            try {
                const parsed = parseResponse(message);
                this.emit('response', parsed);
            } catch (error) {
                console.error(`[Bus] Error parseando mensaje: ${error.message}`);
                this.emit('error', error);
            }
        }
    }

    send(serviceName, data) {
        return new Promise((resolve, reject) => {
            if (!this.isConnected) {
                return reject(new Error('No conectado al bus'));
            }

            // Escuchamos la proxima respuesta UNA SOLA VEZ
            this.once('response', (res) => {
                resolve(res);
            });
            this.once('error', (err) => {
                reject(err);
            });

            const transaction = buildTransaction(serviceName, data);
            // console.log(`[Bus] >> Enviando: ${transaction}`); // Descomentar para depurar
            this.clientSocket.write(transaction);
        });
    }

    disconnect() {
        this.clientSocket.destroy();
    }
}

module.exports = new BusService();