// clients/c1_cliente_web_usuarios/actions/appointmentActions.js
const bus = require('../services/busService');
const ui = require('../ui/consoleUI');
const petActions = require('./petActions');
const jwt = require('jsonwebtoken');

/**
 * Orquesta el proceso completo de agendamiento de un servicio.
 */
async function handleScheduleServiceFlow(token, services) {
    try {
        // 1. Elegir un servicio
        const { itemId: serviceId } = await ui.promptForItemId('servicio', 'agendar');
        const selectedService = services.find(s => s.id === serviceId);
        if (!selectedService) return console.log('\n❌ ID de servicio no válido.');

        // 2. Elegir mascota
        console.log('\nSelecciona la mascota para este servicio:');
        if (!await petActions.handleListPets(token)) {
            return console.log('\n❌ Debes registrar una mascota antes de agendar.');
        }
        const { petId } = await ui.promptForPetSelection();

        // 3. Ver disponibilidad semanal
        const { date } = await ui.promptForDate('ver la disponibilidad de la semana a partir de');
        console.log('\nBuscando horarios disponibles para la semana...');
        const response = await bus.send('CITAS', `versemana;${date};${serviceId}`);

        if (!response.data.startsWith('versemana;')) {
            return console.error('\n❌ Error obteniendo disponibilidad del servidor.');
        }

        const availabilityData = JSON.parse(response.data.split(';')[1]);
        if (Object.keys(availabilityData).length === 0) {
            return console.log('\nℹ️ No hay horarios disponibles para esa semana y servicio.');
        }

        // 4. Mostrar disponibilidad y elegir un slot (día y hora)
        const chosenSlot = await ui.promptForWeeklySlot(availabilityData);
        if (!chosenSlot) return console.log('\nAgendamiento cancelado.');

        // 5. Elegir un veterinario de los disponibles en ese slot
        const availableVets = availabilityData[chosenSlot.day][chosenSlot.time];
        const chosenVet = await ui.promptForVetSelection(availableVets);
        if (!chosenVet) return console.log('\nAgendamiento cancelado.');

        // 6. Confirmar y crear la cita
        const fechaHoraCompleta = `${chosenSlot.day}T${chosenSlot.time}`;
        const confirmacion = await ui.promptForAppointmentConfirmation(selectedService, chosenVet, fechaHoraCompleta);
        if(!confirmacion) return console.log('\nAgendamiento cancelado.');

        const decodedToken = jwt.decode(token);
        const payload = `crear;${decodedToken.id};${petId};${chosenVet.id};${fechaHoraCompleta.slice(0, 16)};${serviceId};Cita agendada desde cliente.`;

        console.log('\nAgendando tu cita...');
        const createResponse = await bus.send('CITAS', payload);

        if (createResponse.status === 'OK' && createResponse.data.startsWith('crear;')) {
            const [, citaId, estado] = createResponse.data.split(';');
            console.log(`\n✅ ¡Cita agendada con éxito! ID: ${citaId}, Estado: ${estado}`);
        } else {
            console.error(`\n❌ Error al crear la cita: ${createResponse.data.split(';')[1]}`);
        }

    } catch (error) {
        console.error(`\nHa ocurrido un error inesperado en el flujo de agendamiento: ${error.message}`);
    }
}

module.exports = {
    handleScheduleServiceFlow
};