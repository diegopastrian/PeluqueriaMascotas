const bus = require('../services/busService');
const ui = require('../ui/consoleUI');
const preferenceActions = require('./preferenceActions');
const cartActions = require('./cartActions');
// Se importa el nuevo manejador de citas. Si el archivo no existe, deberás crearlo.
const appointmentActions = require('./appointmentActions');

/**
 * Muestra el menú principal del catálogo y enruta la selección del usuario
 * a la función correspondiente para listar productos o servicios.
 * @param {string} token - El token de autenticación del usuario.
 */
async function handleCatalogSubMenu(token) {
    let keepInMenu = true;
    while (keepInMenu) {
        // Llama a la función de la UI para mostrar el menú del catálogo
        const choice = await ui.showCatalogMenu();
        switch (choice) {
            case '1':
                // Opción 1: Listar productos
                await handleListProducts(token);
                break;
            case '2':
                // Opción 2: Listar servicios
                await handleListServices(token);
                break;
            case '3':
                // Opción 3: Volver al menú anterior
                keepInMenu = false;
                break;
            default:
                console.log('Opción no válida.');
                break;
        }
    }
}

/**
 * Obtiene y muestra la lista de productos del catálogo desde el servicio S7.
 * Después de mostrar los productos, presenta un menú de acciones específicas para productos.
 * @param {string} token - El token de autenticación del usuario.
 */
async function handleListProducts(token) {
    // Llama al servicio S7 (CATPS) con la operación para listar productos (CATLP)
    const response = await bus.send('CATPS', 'CATLP;');

    if (response.status !== 'OK' || !response.data.startsWith('listar;')) {
        return console.error(`\n❌ Error al listar productos: ${response.message || response.data}\n`);
    }

    try {
        const productsStr = response.data.split(';')[1];
        if (!productsStr) {
            return console.log('\nℹ️ No hay productos en el catálogo.\n');
        }

        // Mapea la respuesta del bus a un array de objetos de producto
        const products = productsStr.split('|').map(p => {
            const [id_producto, nombre, descripcion, precio, stock] = p.split(',');
            return { id: id_producto, name: nombre, description: descripcion, price: precio, stock: parseInt(stock), type: 'producto' };
        });

        console.log('\n--- 📦 Catálogo de Productos ---');
        console.table(products.map(({id, name, price, stock}) => ({ID: id, Nombre: name, Precio: `$${price}`, Stock: stock})));
        console.log('--------------------------------\n');

        let keepGoing = true;
        while(keepGoing) {
            // Muestra un menú de acciones específico para productos
            const choice = await ui.promptForProductAction();
            switch (choice) {
                case 'add_to_cart':
                    // Inicia el flujo para agregar un producto al carrito
                    await cartActions.handleAddToCart(products);
                    break;
                case 'add_preference':
                    // Inicia el flujo para guardar un producto como preferencia
                    const availableIds = products.map(p => p.id);
                    await preferenceActions.handleSavePreference(token, 'producto', availableIds);
                    break;
                case 'back':
                    keepGoing = false;
                    break;
            }
        }
    } catch (e) {
        console.error('\n❌ Error procesando la respuesta del servidor:', e.message);
    }
}

/**
 * Obtiene y muestra la lista de servicios del catálogo desde el servicio S7.
 * Después de mostrar los servicios, presenta un menú de acciones específicas para servicios.
 * @param {string} token - El token de autenticación del usuario.
 */
async function handleListServices(token) {
    // Llama al servicio S7 (CATPS) con la operación para listar servicios (CATLS)
    const response = await bus.send('CATPS', 'CATLS;');

    if (response.status !== 'OK' || !response.data.startsWith('listar;')) {
        return console.error(`\n❌ Error al listar servicios: ${response.message || response.data}\n`);
    }

    try {
        const servicesStr = response.data.split(';')[1];
        if (!servicesStr) {
            return console.log('\nℹ️ No hay servicios en el catálogo.\n');
        }

        // Mapea la respuesta del bus a un array de objetos de servicio
        const services = servicesStr.split('|').map(s => {
            const [id_servicio, nombre, descripcion, precio, tiempo_estimado] = s.split(',');
            return { id: id_servicio, name: nombre, description: descripcion, price: precio, time: tiempo_estimado, type: 'servicio' };
        });

        console.log('\n--- 🛠️ Catálogo de Servicios ---');
        console.table(services.map(({id, name, price, time}) => ({ID: id, Nombre: name, Precio: `$${price}`, 'Tiempo (min)': time})));
        console.log('---------------------------------\n');

        let keepGoing = true;
        while(keepGoing) {
            // Muestra un menú de acciones específico para servicios
            const choice = await ui.promptForServiceAction();
            switch (choice) {
                case 'schedule':
                    // --- ESTA ES LA ACTUALIZACIÓN CLAVE ---
                    // Llama a la nueva función centralizada para agendar un servicio.
                    await appointmentActions.handleScheduleServiceFlow(token, services);
                    // Una vez que el flujo de agendamiento termina, salimos de este submenú.
                    keepGoing = false;
                    break;
                case 'add_preference':
                    // Inicia el flujo para guardar un servicio como preferencia
                    const availableIds = services.map(s => s.id);
                    await preferenceActions.handleSavePreference(token, 'servicio', availableIds);
                    break;
                case 'back':
                    keepGoing = false;
                    break;
            }
        }
    } catch (e) {
        console.error('\n❌ Error procesando la respuesta del servidor:', e.message);
    }
}


module.exports = {
    handleCatalogSubMenu
};