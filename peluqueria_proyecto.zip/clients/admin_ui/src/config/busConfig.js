const BUS_HOST = 'localhost';
const BUS_PORT = 5000;
const SERVICE_CODE = 'AUTEM';

module.exports = { BUS_HOST, BUS_PORT, SERVICE_CODE };